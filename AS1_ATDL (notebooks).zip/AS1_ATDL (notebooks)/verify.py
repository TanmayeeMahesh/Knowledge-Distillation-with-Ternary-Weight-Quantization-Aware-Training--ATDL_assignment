"""
verify_ternary_constraint.py

Standalone verification script for the ternary ResNet18 student.

Purpose
-------
Loads a saved checkpoint (.pth), rebuilds the ternary ResNet18 architecture,
and independently verifies that every TernaryConv2d/TernaryLinear layer's
FORWARD weights are truly constrained to the set {-alpha, 0, +alpha}.

This script is intentionally self-contained: it does not import from the
training notebook, so it can be run on its own to audit a saved checkpoint
after training is finished, on any machine.

Usage
-----
    python verify_ternary_constraint.py --checkpoint path/to/student_best.pth
    python verify_ternary_constraint.py --checkpoint path/to/student_best.pth --clip_value 1.0

Exit code
---------
    0 if every ternary layer passes verification
    1 if any layer's forward weights are found to contain more than 3
      unique values (i.e. the ternary constraint is violated)
"""

import argparse
import sys

import torch
import torch.nn as nn
import torch.nn.functional as F


# --------------------------------------------------------------------------
# Ternary quantization mechanism (must match the training implementation
# exactly: TWN thresholding, per-layer Delta/alpha, clipped STE backward).
# --------------------------------------------------------------------------

class TernarizeSTE(torch.autograd.Function):
    """
    Forward: TWN ternarization. Delta = 0.7 * mean(|W|), alpha = mean(|W_i|)
    over surviving weights (|W_i| > Delta). Per-layer (pooled over the whole
    tensor), not per-channel.

    Backward: clipped/saturated straight-through estimator. Gradient passes
    through unchanged where |W| <= clip_value, zeroed otherwise.
    """

    @staticmethod
    def forward(ctx, W, clip_value):
        delta = 0.7 * W.abs().mean()
        pos_mask = W > delta
        neg_mask = W < -delta
        survivors = W[pos_mask | neg_mask]
        if survivors.numel() > 0:
            alpha = survivors.abs().mean()
        else:
            alpha = torch.tensor(1e-8, device=W.device, dtype=W.dtype)

        W_ternary = torch.zeros_like(W)
        W_ternary[pos_mask] = alpha
        W_ternary[neg_mask] = -alpha

        ctx.save_for_backward(W)
        ctx.clip_value = clip_value
        return W_ternary

    @staticmethod
    def backward(ctx, grad_output):
        (W,) = ctx.saved_tensors
        pass_mask = (W.abs() <= ctx.clip_value).to(grad_output.dtype)
        return grad_output * pass_mask, None


def ternarize(W, clip_value=1.0):
    return TernarizeSTE.apply(W, clip_value)


def compute_twn_stats(W):
    """Non-autograd helper: returns (delta, alpha, sparsity) for a latent weight tensor."""
    with torch.no_grad():
        delta = 0.7 * W.abs().mean()
        pos_mask = W > delta
        neg_mask = W < -delta
        survivors = W[pos_mask | neg_mask]
        alpha = survivors.abs().mean().item() if survivors.numel() > 0 else 0.0
        sparsity = 1.0 - survivors.numel() / W.numel()
    return delta.item(), alpha, sparsity


# --------------------------------------------------------------------------
# Ternary layer modules
# --------------------------------------------------------------------------

class TernaryConv2d(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride=1,
                 padding=0, bias=False, clip_value=1.0):
        super().__init__()
        self.stride = stride
        self.padding = padding
        self.clip_value = clip_value
        self.weight = nn.Parameter(
            torch.empty(out_channels, in_channels, kernel_size, kernel_size)
        )
        nn.init.kaiming_uniform_(self.weight, a=5 ** 0.5)
        self.bias = nn.Parameter(torch.zeros(out_channels)) if bias else None

    def forward(self, x):
        W_ternary = ternarize(self.weight, self.clip_value)
        return F.conv2d(x, W_ternary, self.bias, stride=self.stride, padding=self.padding)

    def get_stats(self):
        return compute_twn_stats(self.weight)


class TernaryLinear(nn.Module):
    def __init__(self, in_features, out_features, bias=True, clip_value=1.0):
        super().__init__()
        self.clip_value = clip_value
        self.weight = nn.Parameter(torch.empty(out_features, in_features))
        nn.init.kaiming_uniform_(self.weight, a=5 ** 0.5)
        self.bias = nn.Parameter(torch.zeros(out_features)) if bias else None

    def forward(self, x):
        W_ternary = ternarize(self.weight, self.clip_value)
        return F.linear(x, W_ternary, self.bias)

    def get_stats(self):
        return compute_twn_stats(self.weight)


# --------------------------------------------------------------------------
# Ternary ResNet18 (CIFAR-adapted) architecture
# --------------------------------------------------------------------------

class TernaryBasicBlock(nn.Module):
    expansion = 1

    def __init__(self, in_channels, out_channels, stride=1, clip_value=1.0):
        super().__init__()
        self.conv1 = TernaryConv2d(in_channels, out_channels, kernel_size=3,
                                    stride=stride, padding=1, bias=False, clip_value=clip_value)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = TernaryConv2d(out_channels, out_channels, kernel_size=3,
                                    stride=1, padding=1, bias=False, clip_value=clip_value)
        self.bn2 = nn.BatchNorm2d(out_channels)

        self.shortcut = nn.Sequential()
        if stride != 1 or in_channels != out_channels:
            self.shortcut = nn.Sequential(
                TernaryConv2d(in_channels, out_channels, kernel_size=1, stride=stride,
                              bias=False, clip_value=clip_value),
                nn.BatchNorm2d(out_channels)
            )

    def forward(self, x):
        identity = self.shortcut(x)
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        return self.relu(out + identity)


class TernaryResNetCIFAR(nn.Module):
    def __init__(self, num_blocks, num_classes=10, clip_value=1.0):
        super().__init__()
        self.in_channels = 64
        self.clip_value = clip_value

        self.stem = nn.Sequential(
            TernaryConv2d(3, 64, kernel_size=3, stride=1, padding=1, bias=False, clip_value=clip_value),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True)
        )
        self.stage1 = self._make_stage(64, num_blocks[0], stride=1)
        self.stage2 = self._make_stage(128, num_blocks[1], stride=2)
        self.stage3 = self._make_stage(256, num_blocks[2], stride=2)
        self.stage4 = self._make_stage(512, num_blocks[3], stride=2)
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = TernaryLinear(512, num_classes, bias=True, clip_value=clip_value)

    def _make_stage(self, out_channels, num_blocks, stride):
        strides = [stride] + [1] * (num_blocks - 1)
        layers = []
        for s in strides:
            layers.append(TernaryBasicBlock(self.in_channels, out_channels, stride=s,
                                             clip_value=self.clip_value))
            self.in_channels = out_channels
        return nn.Sequential(*layers)

    def forward(self, x):
        out = self.stem(x)
        out = self.stage1(out)
        out = self.stage2(out)
        out = self.stage3(out)
        out = self.stage4(out)
        out = self.avgpool(out)
        out = torch.flatten(out, 1)
        return self.fc(out)


def ResNet18Ternary(num_classes=10, clip_value=1.0):
    return TernaryResNetCIFAR(num_blocks=[2, 2, 2, 2], num_classes=num_classes, clip_value=clip_value)

# Add near the top of verify_ternary_constraint(), after building the per-layer loop:
import json

def verify_ternary_constraint(checkpoint_path, clip_value=1.0, num_classes=10, device="cpu",
                                save_report=None):
    ...
    layer_records = []  # add this before the for-loop

    for name, module in model.named_modules():
        if isinstance(module, (TernaryConv2d, TernaryLinear)):
            ...
            layer_records.append({
                "layer": name, "n_weights": module.weight.numel(),
                "n_unique_values": n_unique, "delta": delta, "alpha": alpha,
                "sparsity_pct": sparsity * 100, "passed": passed
            })

    ...
    if save_report:
        report = {
            "checkpoint": checkpoint_path,
            "epoch": checkpoint.get("epoch"), "val_acc": checkpoint.get("val_acc"),
            "T": checkpoint.get("T"), "lam": checkpoint.get("lam"),
            "all_passed": all_passed, "layers": layer_records,
        }
        with open(save_report, "w") as f:
            json.dump(report, f, indent=2)
        print(f"\nSaved verification report to: {save_report}")

    return all_passed


# --------------------------------------------------------------------------
# Verification logic
# --------------------------------------------------------------------------

def verify_ternary_constraint(checkpoint_path, clip_value=1.0, num_classes=10, device="cpu", save_report=None):
    """
    Loads the checkpoint, rebuilds the architecture, and checks EVERY
    TernaryConv2d/TernaryLinear layer's forward weights against the
    {-alpha, 0, +alpha} constraint.

    Returns True if all layers pass, False otherwise. Prints a per-layer
    report either way.
    """
    print(f"Loading checkpoint: {checkpoint_path}")
    checkpoint = torch.load(checkpoint_path, map_location=device)

    model = ResNet18Ternary(num_classes=num_classes, clip_value=clip_value).to(device)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()

    print(f"Checkpoint metadata: epoch={checkpoint.get('epoch', 'N/A')}, "
          f"val_acc={checkpoint.get('val_acc', 'N/A')}, "
          f"T={checkpoint.get('T', 'N/A')}, lam={checkpoint.get('lam', 'N/A')}")
    print("-" * 78)
    print(f"{'Layer':<35} {'#Weights':>10} {'#Unique':>8} {'Delta':>10} {'Alpha':>10} {'Sparsity':>9}")
    print("-" * 78)

    all_passed = True
    total_layers_checked = 0
    layer_records = []

    for name, module in model.named_modules():
        if isinstance(module, (TernaryConv2d, TernaryLinear)):
            total_layers_checked += 1
            W_ternary = ternarize(module.weight, module.clip_value)
            unique_vals = torch.unique(W_ternary)
            delta, alpha, sparsity = module.get_stats()

            n_unique = unique_vals.numel()
            passed = n_unique <= 3
            all_passed = all_passed and passed
            layer_records.append({
                "layer": name,
                "n_weights": module.weight.numel(),
                "n_unique_values": n_unique,
                "delta": delta,
                "alpha": alpha,
                "sparsity_pct": sparsity * 100,
                "passed": passed,
            })

            status = "" if passed else "  <-- FAIL: more than 3 unique values"
            print(f"{name:<35} {module.weight.numel():>10,} {n_unique:>8} "
                  f"{delta:>10.5f} {alpha:>10.5f} {sparsity*100:>8.2f}%{status}")

    print("-" * 78)
    print(f"Checked {total_layers_checked} ternary layers.")
    print(f"RESULT: {'ALL LAYERS PASS' if all_passed else 'FAILURE - SEE ABOVE'} "
          f"the {{-alpha, 0, +alpha}} ternary constraint.")

    if save_report:
        report = {
            "checkpoint": checkpoint_path,
            "epoch": checkpoint.get("epoch"),
            "val_acc": checkpoint.get("val_acc"),
            "T": checkpoint.get("T"),
            "lam": checkpoint.get("lam"),
            "all_passed": all_passed,
            "layers": layer_records,
        }
        with open(save_report, "w") as f:
            json.dump(report, f, indent=2)
        print(f"\nSaved verification report to: {save_report}")

    return all_passed


def main():
    parser = argparse.ArgumentParser(
        description="Verify that a saved ternary ResNet18 checkpoint's weights "
                    "are truly constrained to {-alpha, 0, +alpha}."
    )
    parser.add_argument("--checkpoint", type=str, required=True,
                        help="Path to the saved .pth checkpoint file.")
    parser.add_argument("--clip_value", type=float, default=1.0,
                        help="Clip value used for the STE during training (default: 1.0).")
    parser.add_argument("--num_classes", type=int, default=10,
                        help="Number of output classes (default: 10, for CIFAR-10).")
    parser.add_argument("--device", type=str, default="cpu",
                        help="Device to load the model on (default: cpu).")
    parser.add_argument("--save_report", type=str, default=None,
                        help="Optional path to save the verification report as JSON.")
                        
    args = parser.parse_args()
    
    passed = verify_ternary_constraint(
        checkpoint_path=args.checkpoint,
        clip_value=args.clip_value,
        num_classes=args.num_classes,
        device=args.device,
        save_report=args.save_report
    )

    sys.exit(0 if passed else 1)


if __name__ == "__main__":
    main()